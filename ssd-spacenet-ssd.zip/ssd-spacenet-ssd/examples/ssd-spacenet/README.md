#### Training
From the caffe root folder type, `python examples/ssd-spacenet/ssd_spacenet_train.py`

The only paramteter I've played with is the base learning rate

#### Testing
From the caffe root folder type, `python examples/ssd-spacenet/ssd_spacenet_detect.py`

